def log(a, b):
    from math import log
    res = log(b, a)
    return res

def ln(b):
    from math import  log
    res = log(b)
    return res

def lg(b):
    from math import log
    res = log(b, 10)
    return res

