def root2(n):
    from math import sqrt
    res = sqrt(n)
    return  round(res, 4)

def root3(n):
    res = (n ** (1/3))
    return res
