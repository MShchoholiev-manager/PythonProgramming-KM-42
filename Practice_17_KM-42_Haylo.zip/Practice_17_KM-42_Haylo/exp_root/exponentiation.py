def exp2(n):
    res = n ** 2
    return round(res, 4)

def exp3(n):
    res = n ** 3
    return round(res, 4)

