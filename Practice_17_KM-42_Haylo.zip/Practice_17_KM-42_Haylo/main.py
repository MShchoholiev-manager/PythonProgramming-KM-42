
def input_1():
   from factorial import  factorial
   while True:
       try:
            n = int(input("Enter some n (n>0): "))
            if n>0:
                print(factorial.fact(n))
                break
            elif n<0:
                print("It must be a positive integer!")
            else:
                raise ValueError
       except ValueError:
            print("It must be integer!")

def input_2():
    from exp_root import exponentiation
    while True:
        print('''Select "1" if you want to calculate in second degree
Select "2" if you want to calculate in third degree
Select "0" if you want to exit''')
        try:
            choice_1 = int(input("Choose an action: "))
            if choice_1 == 1:
                while True:
                    try:
                        n = float(input("Enter some number: "))
                        if n:
                            print(exponentiation.exp2(n))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be number!")
            elif choice_1 == 2:
                while True:
                    try:
                        n = float(input("Enter some number: "))
                        if n:
                            print(exponentiation.exp3(n))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be number!")
            elif choice_1 == 0:
                break
            else:
                raise ValueError
        except ValueError:
            print("Choose one of the action!")

def input_3():
    from exp_root import root
    while True:
        print('''Select "1" if you want to find the square root
Select "2" if you want to find the cube root
Select "0" if you want to exit''')
        try:
            choice_2 = int(input("Choose an action: "))
            if choice_2 == 1:
                while True:
                    try:
                        n = float(input("Enter some positive number: "))
                        if n:
                            print(root.root2(n))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be number!")
            elif choice_2 == 2:
                while True:
                    try:
                        n = float(input("Enter some number: "))
                        if n:
                            print(root.root3(n))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be number!")
            elif choice_2 == 0:
                break
            else:
                raise ValueError
        except ValueError:
            print("Choose one of the action!")

def input_4():
    from logarithm import logarithm
    while True:
        print('''Select "1" if you want to calculate a logarithm with an custom base
Select "2" if you want to calculate the natural logarithm
Select "3" if you want to calculate the decimal logarithm
Select "0" if you want to exit''')
        try:
            choice_3 = int(input("Choose an action: "))
            if choice_3 == 1:
                while True:
                    try:
                        a = int(input("Enter some base for logarithm: "))
                        b = int(input("Enter some positive number: "))
                        if a > 0 and a!= 1 and b>0:
                            print(logarithm.log(a, b))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("Error! a must be >0 and not be '1', b must be > 0")
            elif choice_3 == 2:
                while True:
                    try:
                        b = int(input("Enter some positive number: "))
                        if b>0:
                            print(logarithm.ln(b))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be positive number!")
            elif choice_3 == 3:
                while True:
                    try:
                        b = int(input("Enter some positive number: "))
                        if b > 0:
                            print(logarithm.lg(b))
                            break
                        else:
                            raise ValueError
                    except ValueError:
                        print("It must be positive number!")
            elif choice_3 == 0:
                break
            else:
                raise ValueError
        except ValueError:
            print("Choose one of the action!")




print('''Welcome to the lab 17!
Action list:
"1" is factorial
"2" is exponentiation
"3" is root
"4" is logarithm
"0" if you want to finish the program''')
while True:
    try:
        inp = int(input("Select an action from the menu list: "))
        if inp == 1:
            input_1()
        elif inp == 2:
            input_2()
        elif inp == 3:
            input_3()
        elif inp == 4:
            input_4()
        elif inp == 0:
            exit()
        else:
            raise ValueError
    except ValueError:
        print("Choose one of the actions!")






